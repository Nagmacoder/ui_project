import logo from "./logo.svg";
import "./App.css";
import Form from "./form/Form";
import Home from "./pages/Home";
import { Head } from "./component/Head";

function App() {
  return (
    <div className="App">
      {/* <Form /> */}

      <Home />
    </div>
  );
}

export default App;
